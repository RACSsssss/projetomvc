/**
 * Renderiza o formulário para criar uma nova uf.
 * @return {string} HTML do formulário de criação de uf.
 */
function renderizarFormulario() {
  return `
          <form class="mt-3" id="formulario_uf">
              <div class="form-group">
                  <label for="uf_titulo">Nome da uf:</label>
                  <input type="text" class="form-control" id="uf_titulo_formulario">
              </div>
              <button type="submit" class="btn btn-primary mt-2">Salvar</button>
          </form>
      `;
}

/**
 * Renderiza o formulário para atualizar uma uf existente.
 * @param {Object} uf - A uf a ser atualizada.
 * @return {string} HTML do formulário de atualização de uf.
 */
function renderizarFormularioAtualizar(uf) {
    return `
            <form class="mt-3" id="formulario_uf_atualizar">
                <input type="hidden" class="form-control" id="uf_id_formulario" value="${uf.id_uf}">
                <div class="form-group">
                    <label for="uf_titulo">Nome da uf:</label>
                    <input type="text" class="form-control" id="uf_titulo_formulario" value="${uf.no_uf}">
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
}

  /**
 * Renderiza a tabela de uf.
 * @param {Array} uf - Lista de uf a serem exibidas.
 * @return {string} HTML da tabela de uf.
 */
function renderizarTabela(uf) {
  let tabela = `
          <table class="table table-striped mt-3">
              <thead>
                  <tr>
                      <th>Nome da uf</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
      `;

  uf.forEach((uf) => {
    tabela += `
              <tr>
                  <td>${uf.no_uf}</td>
                  <td>
                    <button class="excluir-btn" uf-id=${uf.id_uf}>Excluir</button>
                    <button class="atualizar-btn" uf-atualizar-id=${uf.id_uf}>Atualizar</button>
                  </td>
              </tr>
          `;
  });

  tabela += `
              </tbody>
          </table>
      `;

  return tabela;
}

const ufView = {
    renderizarFormulario,
    renderizarTabela,
    renderizarFormularioAtualizar
};

export default ufView;
