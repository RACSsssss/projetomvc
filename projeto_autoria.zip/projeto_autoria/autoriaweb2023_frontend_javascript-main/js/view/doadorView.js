/**
 * Renderiza o formulário para criar uma nova doador.
 * @return {string} HTML do formulário de criação de doador.
 */
function renderizarFormulario() {
  return `
          <form class="mt-3" id="formulario_doador">
              <div class="form-group">
                  <label for="doador_titulo">Nome do doador:</label>
                  <input type="text" class="form-control" id="doador_titulo_formulario">
              </div>
              <button type="submit" class="btn btn-primary mt-2">Salvar</button>
          </form>
      `;
}

/**
 * Renderiza o formulário para atualizar uma doador existente.
 * @param {Object} doador - A doador a ser atualizada.
 * @return {string} HTML do formulário de atualização de doador.
 */
function renderizarFormularioAtualizar(doador) {
    return `
            <form class="mt-3" id="formulario_doador_atualizar">
                <input type="hidden" class="form-control" id="doador_id_formulario" value="${doador.cpf_doador}">
                <div class="form-group">
                    <label for="doador_titulo">Nome do doador:</label>
                    <input type="text" class="form-control" id="doador_titulo_formulario" value="${doador.no_doador}">
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
}

  /**
 * Renderiza a tabela de doador.
 * @param {Array} doador - Lista de doador a serem exibidas.
 * @return {string} HTML da tabela de doador.
 */
function renderizarTabela(doador) {
  let tabela = `
          <table class="table table-striped mt-3">
              <thead>
                  <tr>
                      <th>Nome do doador</th>
                  </tr>
              </thead>
              <tbody>
      `;

  doador.forEach((doador) => {
    tabela += `
              <tr>
                  <td>${doador.no_doador}</td>
                  <td>
                    <button class="excluir-btn" doador-id=${doador.cpf_doador}>Excluir</button>
                    <button class="atualizar-btn" doador-atualizar-id=${doador.cpf_doador}>Atualizar</button>
                  </td>
              </tr>
          `;
  });

  tabela += `
              </tbody>
          </table>
      `;

  return tabela;
}

const doadorView = {
    renderizarFormulario,
    renderizarTabela,
    renderizarFormularioAtualizar
};

export default doadorView;
