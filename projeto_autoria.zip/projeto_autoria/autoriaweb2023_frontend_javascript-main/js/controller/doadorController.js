import doadorView from "../view/doadorView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de doador.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizardoadorFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = doadorView.renderizarFormulario();
  document.getElementById("formulario_doador").addEventListener("submit", cadastrardoador);
}

/**
 * Cadastra uma nova doador.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrardoador(event) {
  event.preventDefault();
  const no_doador= document.getElementById("doador_titulo_formulario").value;
  const novadoador = { no_doador: no_doador };

  try {
    await fetch(`${API_BASE_URL}/doador`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novadoador),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListadoador(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar doador:", error);
  }
}
/**
 * Renderiza a lista de doador.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListadoador(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/doador");
    const doadorBD = await response.json(); 

    const doador = doadorBD.map((row) => {
      return {
        cpf_doador: row.cpf_doador,
        no_doador: row.no_doador,
      };
    });
    componentePrincipal.innerHTML = doadorView.renderizarTabela(doador);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar doador:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de doador.
 * Cada botão, quando clicado, aciona a função de exclusão de doador correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const doadorId = this.getAttribute("doador-id");
      excluirdoador(doadorId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de doador.
 * Cada botão, quando clicado, aciona a função de buscar a doador específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const cpf_doador = this.getAttribute("doador-atualizar-id");
      buscardoador(cpf_doador);
    });
  });
}

 
/**
 * Exclui uma doador específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de doador é atualizada.
 * @param {string} id - ID da doador a ser excluída.
 */
async function excluirdoador(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/doador/${id}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir a doador");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListadoador(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir a doador:", error);
  }
}

/**
 * Busca uma doador específica para atualização, com base no ID.
 * Após encontrar a doador, renderiza o formulário de atualização.
 * @param {string} id - ID da doador a ser buscada.
 */
async function buscardoador(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/doador/${id}`);
    const doadorBD = await response.json();
    if (doadorBD.length <= 0) return;

    const doador = doadorBD.map(row => ({
      cpf_doador: row.cpf_doador,
      no_doador: row.no_doador,
  
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = doadorView.renderizarFormularioAtualizar(doador);
    document.getElementById("formulario_doador_atualizar").addEventListener("submit", atualizardoador);
  } catch (error) {
    console.error("Erro ao buscar doador:", error);
  }
}

/**
 * Atualiza uma doador específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizardoador(event) {
  event.preventDefault();

  const cpf_doador = document.getElementById("doador_id_formulario").value;
  const no_doador = document.getElementById("doador_titulo_formulario").value;
  
  const doador = {cpf_doador: cpf_doador, no_doador: no_doador,};

  try {
    const response = await fetch(`${API_BASE_URL}/doador`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(doador),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar a doador");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListadoador(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar doador:", error);
  }
}

const doadorController = {
  renderizardoadorFormulario,
  cadastrardoador,
  renderizarListadoador,
  excluirdoador,
};

export default doadorController;
