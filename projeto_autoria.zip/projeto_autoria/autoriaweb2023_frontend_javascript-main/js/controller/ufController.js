import ufView from "../view/ufView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de uf.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarufFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = ufView.renderizarFormulario();
  document.getElementById("formulario_uf").addEventListener("submit", cadastraruf);
}

/**
 * Cadastra uma nova uf.
 * @param {Event} event - Evento do formulário.
 */
async function cadastraruf(event) {
  event.preventDefault();
  const no_uf = document.getElementById("uf_titulo_formulario").value;
  
  const novauf = { no_uf: no_uf,};

  try {
    await fetch(`${API_BASE_URL}/uf`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novauf),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListauf(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar uf:", error);
  }
}
/**
 * Renderiza a lista de uf.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListauf(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/uf");
    const ufBD = await response.json(); 

    const uf = ufBD.map((row) => {
      return {
        id_uf: row.id_uf,
        no_uf: row.no_uf, 
      };
    });
    componentePrincipal.innerHTML = ufView.renderizarTabela(uf);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar uf:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de uf.
 * Cada botão, quando clicado, aciona a função de exclusão de uf correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const ufId = this.getAttribute("uf-id");
      excluiruf(ufId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de uf.
 * Cada botão, quando clicado, aciona a função de buscar a uf específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const ufId = this.getAttribute("uf-atualizar-id");
      buscaruf(ufId);
    });
  });
}

/**
 * Exclui uma uf específica com base no ID.
 * Após a exclusão bem-sucedida, a lista de uf é atualizada.
 * @param {string} id - ID da uf a ser excluída.
 */
async function excluiruf(id) {
  try {
    const response = await fetch(`${API_BASE_URL}/uf/${id}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir a uf");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListauf(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir a uf:", error);
  }
}

/**
 * Busca uma uf específica para atualização, com base no ID.
 * Após encontrar a uf, renderiza o formulário de atualização.
 * @param {string} id_uf - ID da uf a ser buscada.
 */
async function buscaruf(id_uf) {
  try {
    const response = await fetch(`${API_BASE_URL}/uf/${id_uf}`);
    const ufBD = await response.json();
    if (ufBD.length <= 0) return;

    const uf = ufBD.map(row => ({
      id_uf: row.id_uf,
      no_uf: row.no_uf,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = ufView.renderizarFormularioAtualizar(uf);
    document.getElementById("formulario_uf_atualizar").addEventListener("submit", atualizaruf);
  } catch (error) {
    console.error("Erro ao buscar uf:", error);
  }
}

/**
 * Atualiza uma uf específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizaruf(event) {
  event.preventDefault();

  const id_uf = document.getElementById("uf_id_formulario").value;
  const no_uf = document.getElementById("uf_titulo_formulario").value;
  const uf = {id_uf: id_uf, no_uf: no_uf,};

  try {
    const response = await fetch(`${API_BASE_URL}/uf`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(uf),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar a uf");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListauf(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar uf:", error);
  }
}

const ufController = {
  renderizarufFormulario,
  cadastraruf,
  renderizarListauf,
  excluiruf,
};

export default ufController;
